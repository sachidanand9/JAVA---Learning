package P1;
/*
 * 10 = 1010
 * 3 = 11
 * 5 = 101
 */
public class Binary2Decimal {
	public static void main(String[] args) {
		String bin="";
		int n=10;
		while(n>0) {
			int r=n%2;
			bin=r+bin;
			n=n/2;
		}
		
		System.out.println(bin);
	}
 
}
