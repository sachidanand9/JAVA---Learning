package P1;

import java.util.Scanner;

//WAJP to read Character from the user and find out weather it is alphabet,integer or special character
public class FindCharacter {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a Number");
	    char ch=sc.next().charAt(0);
	    
	    if(ch>='A' && ch<='Z' || ch>'a' && ch<'z') {
	    	System.out.println("Alphabet");
	    }
	    else if(ch>='0' && ch<='9') {
	    	System.out.println("Digit");
	    	
	    }
	    else {
	    	System.out.println("Special Character");
	    }
	}

}
