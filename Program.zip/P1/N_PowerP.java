package P1;
//WAJP to difne a method to return ( n to the power of p)
import java.util.Scanner;

public class N_PowerP {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		System.out.println("Enter Power: ");
		int p=sc.nextInt();
		
		System.out.println(Power(n,p));
		
	}
	public static int Power(int n,int p) {
		int res=1;
//		while(p>0) {
//			res=res*n;
//			p--;
//		}
		
		for(int i=1; i<=p; i++) {
			res=res*n;
		}
		return res;
		
	}

}
