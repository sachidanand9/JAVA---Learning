package P1;

import java.util.Scanner;

public class EvenOddCount {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		
		int even=0;
		int odd=0;
		
		while(n>0) {
			int r=n%10;
			if(r%2==0) {
				even++;
			}
			else {
				odd++;
				
			}
			n=n/10;
		}
		System.out.println("EvenCount:"+even);
		System.out.println("Odd count "+odd);
	}

}
