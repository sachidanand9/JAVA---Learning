package P1;

import java.util.Scanner;

//public class PrimeNo {
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("Enter 3 digit: ");
//		int n=sc.nextInt();
//		
//		if(prime(n)) {
//			System.out.println("prime");
//		}
//		else {
//			System.out.println("not a prime");
//		}
//	}
//	public static boolean prime(int n) {
//		for(int i=2;i<n/2; i++) {
//			if(n%2==0) {
//				return false;
//			}
//			
//		}
//		return true;
//	}
//
//}

public class PrimeNo {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a 3-digit number: ");
		int n = sc.nextInt();

		if (prime(n)) {
			System.out.println(n + " is a prime number.");
		} else {
			System.out.println(n + " is not a prime number.");
		}
	}

	public static boolean prime(int n) {
		// Check if the number is less than or equal to 1
		if (n <= 1) {
			return false;
		}

		for (int i = 2; i <= n/2; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}
}