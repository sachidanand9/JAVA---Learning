package P1;

// WAJP to user enter number into positive number Format

import java.util.Scanner;
public class PostiveNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		if(n<0) {
			n=n* -1;
			
		}
		System.out.println(n);
	}
}
