package P1;

import java.util.Scanner;

public class Biggest2No {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		
		int big=a>b?a:b;
		 big=big>c?big:c;
		
		System.out.println("Big number is:"+big);
		
	}

}
