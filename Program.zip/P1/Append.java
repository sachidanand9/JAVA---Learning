package P1;

public class Append {
 public static void main(String[] args) {
	System.out.println(2+5+"ABC"+2+5);
	System.out.println(2+5+"ABC"+2*5);
	System.out.println(2+5+"ABC"+2/5);
	
	
//	System.out.println(2+5+"ABC"+6-5); Compile time Error
	
//   Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
//	The operator - is undefined for the argument type(s) String, int

//	at Java_Programming/P1.Append.main(Append.java:6)

}
}
