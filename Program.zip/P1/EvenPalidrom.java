package P1;

// WAJP to Create a method to return true if the even number is palindrom
import java.util.Scanner;

public class EvenPalidrom {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		
		System.out.println(palidrom(n));
	}
	public static boolean palidrom(int n) {
		int temp=n;
		int rev=0;
		while(n>0) {
			
			int r=n%10;
			rev=rev*10+r;
			n=n/10;
		}
		return temp==rev;
	}

}
