package P1;

import java.util.Scanner;

// WAJP to read the month number from the user and print the   month is valid or not

public class MonthNoFind {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Month number: ");
		int a = sc.nextInt();

		if (a <= 1 && a >= 12) {
			System.out.println("Valid");
		} else {
			System.out.println("not Valid");
		}
	}

}
