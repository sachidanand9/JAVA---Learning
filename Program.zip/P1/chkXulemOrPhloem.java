package P1;

import java.util.Scanner;

public class chkXulemOrPhloem {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 digit: ");
		int n=sc.nextInt();
		xylem(n);
	}
	public static void xylem(int n) {
		int odd=0,id=0;
		int temp=n;
		while(n>0) {
			int r=n%10;
			if(temp==n|| r==n) {
				odd+=r;
			}
			else {
				id+=r;
			}
			n=n/10;
		}
		if(odd==id) {
			System.out.println("Xylem");
		}
		else {
			System.out.println("phloem");
		}
	}

}
