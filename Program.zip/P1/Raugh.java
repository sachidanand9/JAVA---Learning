package P1;

public class Raugh {
	public static void main(String[] args) {
		int n=46;
		int r=n%10;
		
		int a=46;
		int t=a/10;
		System.out.println(r);
		System.out.println(t);
	}

}
