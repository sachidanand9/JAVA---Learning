package P1;

import java.util.Scanner;

public class Diffrent3No {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    System.out.println("Enter a Number");
	    int a=sc.nextInt();
	    int b=sc.nextInt();
	    int c=sc.nextInt();
	    
	    int big=(a>b && a>c)?a:(b>c)?b:c;
	    int small=(a<b && a<c)? a:(b<c)?b:c;
	    
	    int mid=(a+b+c)-(big+small);
	    System.out.println(small+" " +mid+" "+big);	
	}
	

}
