package P1;

// WAJP to find user enter integer is digit or number 
import java.util.Scanner;

public class NumberDigitFind {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 number: ");
		int a=sc.nextInt();
		
		if(a>=-9 && a<=9) {
			System.out.println("This is Digit");
		}
		else {
			System.out.println("This is numbers");
		}
	}

}
