package P1;
//WAJP to Create a method to return count of digits in the number

import java.util.Scanner;

public class CountDigit {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		
//		int res=countDigits(n);
//		System.out.println(res);
		System.out.println(countDigits(n));
		
	}
    public static int countDigits(int n) {
    	int count=0;
    	while(n>0) {
    		count++;
    		n=n/10;
    	}
    	return count;
    }
}
