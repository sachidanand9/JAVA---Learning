package P1;

// WAJP to read for subject marks and print distiction,first class,second class,just pass,fail
import java.util.Scanner;

public class StudentResult1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Student Name: ");
		String s=sc.nextLine();
		System.out.println("Enter Java Marks :");
		int a=sc.nextInt();
		System.out.println("Enter Programming Marks :");
		int b=sc.nextInt();
		System.out.println("Enter React Marks :");
		int c=sc.nextInt();
		System.out.println("Enter SQL Marks :");
		int d=sc.nextInt();
		
		if(a<35||b<35||c<35||d<35) {
			System.out.println("Fail");
		}
		else {
			int avr=(a+b+c+d)/4;
			
			System.out.println("Average is "+avr);
			if(avr>=85) {
				System.out.println("Distinct");
			}
			else if(avr>=65)
			{
				System.out.println("1st Class");
			}
			else if(avr>55) {
				System.out.println("2nd Class");
				
			}
			else{
				System.out.println("just pass");
			}
		}
		
		
	}

}
