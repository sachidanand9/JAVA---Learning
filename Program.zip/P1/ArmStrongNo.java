package P1;

import java.util.Scanner;

// WAJP to print user entered number is a arm strong number or not (Only for 3 digits)
public class ArmStrongNo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 digit: ");
		int n=sc.nextInt();
		
		armstrong(n);
	}
	public static void armstrong(int n) {
		int temp=n;
		int sum=0;
		while(n>0) {
			
			int r=n%10;
			sum=sum+r*r*r;
			n=n/10;
		}
		if(temp==sum) {
			System.out.println("Armstrong= "+temp);
		}
		else {
			System.out.println("not a armstrong= "+temp);
		}
	}

}
