package P1;

public class Decimal2Hexadecimal {
	public static void main(String[] args) {
		String hex="";
		int n=1580;
		while(n>0) {
			int r=n%16;
			if(r<10) {
				hex=r+hex;
			}
			else {
				hex=(char)(55+r)+hex;
			}
//			else if(r==10) {
//				hex="A"+hex;
//			}
//			else if(r==11) {
//				hex="B"+hex;
//			}
//			else if(r==12) {
//				hex="C"+hex;
//			}
//			else if(r==13) {
//				hex="E"+hex;
//			}
//			else if(r==14) {
//				hex="F"+hex;
//			}
//			else if(r==15) {
//				hex="G"+hex;
//			}
			n=n/16;
		}
		System.out.println(hex);
	}
	// int n=65;
//	char c=(char)n;
//system.out.prinln(c);

}
