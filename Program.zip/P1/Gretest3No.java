package P1;

import java.util.Scanner;

// WAJP to find the Greatest of Three number
public class Gretest3No {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 number: ");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		
		int  big=a;
		if(big<b)
			big=b;
		if(big<c)
			big=c;
		
		System.out.println("Bigest number is :" +big);
	}

}
