package P1;
import java.util.Scanner;
public class ReverseNo {
	/*
	 * int rev=0;
	 * int n=234;
	 * while(n>0){
	 * int r=n%10;
	 * rev=rev*10+r
	 * n=n/10;}
	 * S.o.pl("rev")
	 */
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		
		int rev=0;
		while(n>0) {
			int r=n%10;
			rev=rev*10+r;
		}
	}

}
