package P1;

import java.util.Scanner;

public class DiseriumNo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		
		int sum=0 ,temp=n;
		int c=count(n);
		
		while(n>0) {
			int r=n%10;
			sum=sum+power(r,c);
			c--; //Deserium
			n=n/10;
		}
		if(temp==sum) {
			System.out.println("Diserium");
		}
		else {
			System.out.println("Not Diserium");
		}
	}
	public static int power(int n,int p) {
		int res=1;
		for(int i=1; i<=p; i++) {
			res=res*n;
		}
		return res;
	}
	public static int count(int n) {
		int count=0;
		while(n>0) {
			count++;
			n=n/10;
		}
		return count;
	}
	

}
