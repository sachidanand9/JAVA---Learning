package P1;
//define a method to find bigest digit from the number

import java.util.Scanner;

public class BigDigitFind {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		System.out.println(bigdigit(n));
	}
	public static int bigdigit(int n) {
		int big=-9;
//		while(n>0) {
//			int r=n%10;
//			if(big<r) {
//				big=r;
//			}
//			n=n/10;
//		}
//		return big;
		do {
			int r=n%10;
			if(big<r) {
				big=r;
			}
			n=n/10;
		}while(n>0);
		return big;
		
	}

}
