package P1;

import java.util.Scanner;

public class FindEven_Odd {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 3 number: ");
		int a=sc.nextInt();
		
//		String[] res= {"even","Odd"};
//		
//		System.out.println(res[a%2]);
//		
//		res[0]="even";
//		res[1]="Odd";
		
		
//		if(a%2==0) {
//			System.out.println("Number is even");
//		}
//		else {
//			System.out.println("Number is odd");
//		}
		
//		switch(a%2)
//		{
//		case 0:
//			System.out.println("Even");
//			break;
//		case 1:
//		     System.out.println("Odd");
//		   
//		}
		
		if(a/2*2==0) {
			System.out.println("Even");
		}
		else {
			System.out.println("Odd");
		}
	}

}
