package P1;

import java.util.Scanner;

public class SpecialNumber {
	public static void specialn(int n) {
		int l=n%10; //6
		int f=n/10; //4
		int res=(l+f)+(l*f); //10 + 24 =34
		
		if(n==res)
			System.out.println("Special 2 digit");
		else {
			System.out.println("not a special 2 digit");
		}
	}
		
		public static void main(String [] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("enter 2 digit number:");
			int n=sc.nextInt();
			specialn(n);
		
	}

}
