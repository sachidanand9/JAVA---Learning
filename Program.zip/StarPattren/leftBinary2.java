package StarPattren;

/*
 * 1 
   0 1 
   0 1 0 
   1 0 1 0 
 */

import java.util.Scanner;

public class leftBinary2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter  Number: ");
		int n=sc.nextInt();
		int x=1;
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=i; j++) {
				System.out.print(x%2+" ");
				x++;
			}
			System.out.println();
		}
	}

}
