package Bitwise_Operator;

public class BitewiseOperator {
 public static void main(String[] args) {
	System.out.println(9|10);
	System.out.println(9 & 10);
	
//	System.out.println(~9);
	System.out.println(9 ^ 10);
	System.out.println(9 << 1);
	System.out.println(9 >> 1);
}
}
