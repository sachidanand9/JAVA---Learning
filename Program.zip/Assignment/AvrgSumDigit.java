package Assignment;

import java.util.Scanner;

public class AvrgSumDigit {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		System.out.println(Avrgsumdigit(n));
		
	}
	public static double Avrgsumdigit(int n) {
		int c=0;
		int sum=0;
		while(n>0) {
			int r=n%10;
			sum=sum+r;
			c++;
			n=n/10;
		}
		return sum/c;
	}

}
