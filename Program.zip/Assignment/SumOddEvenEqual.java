package Assignment;

//WAJP to define a method to return best if sum of even digits is equal to sum of odd digit
import java.util.Scanner;

public class SumOddEvenEqual {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		
		System.out.println(evenOdd(n));
	}
	public static String evenOdd(int n) {
		int even=0;
		int odd=0;
		
		while(n>0) {
			int r=n%10;
			if(r%2==0) {
				even+=r;
			}
			else {
				odd+=r;
				
			}
			n=n/10;
		}
		
		if(even==odd) {
			return "Best";
		}
		else {
			return "Worst";
		}
	}
	
}
