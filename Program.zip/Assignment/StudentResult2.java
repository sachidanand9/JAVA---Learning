package Assignment;

import java.util.Scanner;

public class StudentResult2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Student Name: ");
		String s=sc.nextLine();
		System.out.println("Enter Java Marks :");
		int a=sc.nextInt();
		System.out.println("Enter Programming Marks :");
		int b=sc.nextInt();
		System.out.println("Enter React Marks :");
		int c=sc.nextInt();
		System.out.println("Enter SQL Marks :");
		int d=sc.nextInt();
		
		if(a<35 || b<35 || c<35 || d<35) {
			System.out.println("Fail");
		}
		else
		{
			System.out.println("Pass");
		}
	}

}
