package Assignment;

import java.util.Scanner;

public class StudentResult1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Student Name: ");
		String s=sc.nextLine();
		System.out.println("Enter Java Marks :");
		int a=sc.nextInt();
		System.out.println("Enter Programming Marks :");
		int b=sc.nextInt();
		System.out.println("Enter React Marks :");
		int c=sc.nextInt();
		System.out.println("Enter SQL Marks :");
		int d=sc.nextInt();
		
		int sum=a+b+c+d;
		int avg=sum/4;
		
		if(avg> 85 && avg<100 ) {
			System.out.println("Student "+s+" Pass for grade A");
		}
		else if(avg>70 && avg<85) {
			System.out.println("Student "+s+" Pass for grade B");
		}
		else if(avg>55 && avg<70) {
			System.out.println("Student "+s+" Pass for grade C");
		}
		else if(avg>40 && avg<55) {
			System.out.println("Student "+s+" Pass for grade D");
		}
		else {
			System.out.println("Student "+s+" Fail for grade E");
		}
	}

}
