package Assignment;

import java.util.Scanner;
public class FInd5BigestNo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 5 Numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int d=sc.nextInt();
		int e=sc.nextInt();
		
		int big=a;
		
		if(big<b);
		 big=b;
		if(big<c)
			big=c;
		if(big<d)
			big=d;
		if(big<e)
			big=e;
		
		System.out.println(big);
		
	}

}
