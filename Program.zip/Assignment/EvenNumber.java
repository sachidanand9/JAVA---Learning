package Assignment;

public class EvenNumber {
	public static void main(String[] args) {
		/* int n=2 3 4 6
		 * while(n>0){
		 * int r=n%10;
		 * if(r%2==0){
		 * s.o.pl(r);
		 * }
		 * n=n/10;
		 * }
		 */
		
	}

}
