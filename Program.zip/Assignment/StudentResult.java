package Assignment;

//WAJP to read for subject marks and find out weather he is passes or fail
import java.util.Scanner;
public class StudentResult {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Student Name: ");
		String s=sc.nextLine();
		System.out.println("Enter Java Marks :");
		int a=sc.nextInt();
		System.out.println("Enter Programming Marks :");
		int b=sc.nextInt();
		System.out.println("Enter React Marks :");
		int c=sc.nextInt();
		System.out.println("Enter SQL Marks :");
		int d=sc.nextInt();
		
		int sum=a+b+c+d;
		int avg=sum/4;
		
		if(avg>70) {
			System.out.println("Student "+s+" Pass for "+avg+" Percentage");
		}
		else {
			System.out.println("Student "+s+" Fail for "+avg+" Percentage");
		}
	}

}
