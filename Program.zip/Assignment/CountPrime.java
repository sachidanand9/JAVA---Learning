package Assignment;

import java.util.Scanner;

public class CountPrime {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number: ");
		int n=sc.nextInt();
		System.out.println(countePrime(n));
	}
		public static int countePrime(int n) {
		int count=0;
		while(n>0) {
			int r=n%10;
			if (r==2 || r==3 || r==5 || r==7) {
				count++;
			}
			n=n/10;
		}
		return count;
	
	}
	
}
