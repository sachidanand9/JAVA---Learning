package Assignment;

public class Binary_Decimal {
	    public static void main(String[] args) {
//	        String bin = "1010";  // Binary input as a string
//	        int decimal = 0;
//	        int index = 0;
//
//	        while (index < bin.length()) {
//	            char bit = bin.charAt(bin.length() - 1 - index);
//	            if (bit == '1') {
//	                decimal += Math.pow(2, index);
//	            }
//	            index++;
//	        }
//
//	        System.out.println(decimal);
	    	
	    	int sum=0;
	    	int p=1;
	    	int n=1010;
	        while(n>0) {
	        	int r=n%10;
	        	sum=sum+r*p;
	        	p=p*2;
	        	n=n/10;
	        }
	        System.out.println(sum);
	    }
	}

